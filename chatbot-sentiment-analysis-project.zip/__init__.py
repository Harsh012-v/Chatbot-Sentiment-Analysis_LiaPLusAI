"""Test package for chatbot sentiment analysis"""

